<?php

namespace App\Filament\Resources\Products\Schemas;

use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class ProductForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('sku')
                    ->label('SKU')
                    ->default(null),
                TextInput::make('name')
                    ->required(),
                TextInput::make('slug')
                    ->required(),
                Textarea::make('description')
                    ->default(null)
                    ->columnSpanFull(),
                Textarea::make('allergens')
                    ->default(null)
                    ->columnSpanFull(),
                FileUpload::make('image_path')
                    ->image(),
                TextInput::make('category_id')
                    ->numeric()
                    ->default(null),
                Textarea::make('product_options')
                    ->default(null)
                    ->columnSpanFull(),
                TextInput::make('base_price')
                    ->required()
                    ->numeric(),
                Toggle::make('pre_order')
                    ->required(),
                TextInput::make('pre_order_expectation')
                    ->default(null),
                Toggle::make('seasonal')
                    ->required(),
                DatePicker::make('season_start'),
                DatePicker::make('season_end'),
                TextInput::make('inventory')
                    ->required()
                    ->numeric()
                    ->default(0),
                Toggle::make('active')
                    ->required(),
            ]);
    }
}
