<?php

namespace App\Filament\Resources\Product;

use App\Filament\Resources\Products\Pages\CreateProduct;
use App\Filament\Resources\Products\Pages\EditProduct;
use App\Filament\Resources\Products\Pages\ListProducts;
use App\Filament\Resources\Products\Pages\ViewProduct;
use App\Models\Product;
use App\Models\Category;
use Filament\Resources\Resource;
use Filament\Forms;
use Filament\Tables;
use Filament\Schemas\Schema;
use Filament\Tables\Table;
use Filament\Support\Icons\Heroicon;
use BackedEnum;
use UnitEnum;

class ProductResource extends Resource
{
    protected static ?string $model = Product::class;

    // match Filament v4 type expectations (same as your CategoryResource)
    protected static BackedEnum|string|null $navigationIcon = Heroicon::Cube;
    protected static UnitEnum|string|null $navigationGroup = 'Product Management';
    protected static ?string $navigationLabel = 'Products';
    protected static ?string $recordTitleAttribute = 'name';

    public static function form(Schema $schema): Schema
    {
        return $schema->schema([
            Forms\Components\TextInput::make('name')
                ->label('Product Name')
                ->required()
                ->maxLength(255),

            Forms\Components\Select::make('category_id')
                ->label('Category')
                ->options(fn () => Category::pluck('name', 'id')->toArray())
                ->searchable()
                ->required(),

            Forms\Components\Textarea::make('description')
                ->label('Description')
                ->rows(3)
                ->nullable(),

            Forms\Components\TextInput::make('base_price')
                ->label('Base Price')
                ->numeric()
                ->required(),

            Forms\Components\FileUpload::make('image_path')
                ->label('Product Image')
                ->directory('products')
                ->image()
                ->nullable(),

            Forms\Components\Repeater::make('product_options')
                ->schema([
                    Forms\Components\TextInput::make('option_name')->label('Option Name'),
                    Forms\Components\TagsInput::make('option_values')->label('Values (comma separated)'),
                ])
                ->collapsed()
                ->columns(2)
                ->label('Product Options'),

            Forms\Components\Toggle::make('pre_order')->label('Pre-order'),
            Forms\Components\TextInput::make('pre_order_expectation')->maxLength(255)->nullable(),

            Forms\Components\Toggle::make('seasonal'),
            Forms\Components\DatePicker::make('season_start')->nullable(),
            Forms\Components\DatePicker::make('season_end')->nullable(),

            Forms\Components\TextInput::make('inventory')->numeric()->default(0),
            Forms\Components\Toggle::make('active')->default(true),
        ])->columns(2);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('image_path')
                    ->label('Image')
                    ->circular()
                    ->size(40),

                Tables\Columns\TextColumn::make('name')
                    ->label('Name')
                    ->sortable()
                    ->searchable(),

                Tables\Columns\TextColumn::make('category.name')
                    ->label('Category'),

                Tables\Columns\TextColumn::make('base_price')
                    ->label('Base Price'),

                Tables\Columns\IconColumn::make('active')
                    ->label('Active')
                    ->boolean(),
            ])
            ->filters([
                //
            ])
            ->recordUrl(null) // same as your CategoryResource — optional
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => ListProducts::route('/'),
            'create' => CreateProduct::route('/create'),
            'view' => ViewProduct::route('/{record}'),
            'edit' => EditProduct::route('/{record}/edit'),
        ];
    }
}
