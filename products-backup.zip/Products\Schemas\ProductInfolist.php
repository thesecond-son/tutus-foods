<?php

namespace App\Filament\Resources\Products\Schemas;

use Filament\Infolists\Components\IconEntry;
use Filament\Infolists\Components\ImageEntry;
use Filament\Infolists\Components\TextEntry;
use Filament\Schemas\Schema;

class ProductInfolist
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextEntry::make('sku')
                    ->label('SKU')
                    ->placeholder('-'),
                TextEntry::make('name'),
                TextEntry::make('slug'),
                TextEntry::make('description')
                    ->placeholder('-')
                    ->columnSpanFull(),
                TextEntry::make('allergens')
                    ->placeholder('-')
                    ->columnSpanFull(),
                ImageEntry::make('image_path')
                    ->placeholder('-'),
                TextEntry::make('category_id')
                    ->numeric()
                    ->placeholder('-'),
                TextEntry::make('product_options')
                    ->placeholder('-')
                    ->columnSpanFull(),
                TextEntry::make('base_price')
                    ->numeric(),
                IconEntry::make('pre_order')
                    ->boolean(),
                TextEntry::make('pre_order_expectation')
                    ->placeholder('-'),
                IconEntry::make('seasonal')
                    ->boolean(),
                TextEntry::make('season_start')
                    ->date()
                    ->placeholder('-'),
                TextEntry::make('season_end')
                    ->date()
                    ->placeholder('-'),
                TextEntry::make('inventory')
                    ->numeric(),
                IconEntry::make('active')
                    ->boolean(),
                TextEntry::make('created_at')
                    ->dateTime()
                    ->placeholder('-'),
                TextEntry::make('updated_at')
                    ->dateTime()
                    ->placeholder('-'),
            ]);
    }
}
